package com.example.vehical_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
