package com.example.vehical_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicalServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicalServiceApplication.class, args);
	}

}
